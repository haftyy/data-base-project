﻿namespace FinalProject
{
    partial class Add_food
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtFoodName = new System.Windows.Forms.TextBox();
            this.txtFoodID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnofferdetails = new System.Windows.Forms.Button();
            this.btnmanageoffers = new System.Windows.Forms.Button();
            this.btnlogout = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnfooddetails = new System.Windows.Forms.Button();
            this.btnmanagefood = new System.Windows.Forms.Button();
            this.btnaddfood = new System.Windows.Forms.Button();
            this.btnuserdetails = new System.Windows.Forms.Button();
            this.btnmanageuser = new System.Windows.Forms.Button();
            this.btnadduser = new System.Windows.Forms.Button();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(599, 350);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(116, 48);
            this.btnCancel.TabIndex = 21;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAdd.Location = new System.Drawing.Point(344, 350);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(116, 48);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click_1);
            // 
            // txtPrice
            // 
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.Location = new System.Drawing.Point(537, 247);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(178, 26);
            this.txtPrice.TabIndex = 19;
            // 
            // txtFoodName
            // 
            this.txtFoodName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFoodName.Location = new System.Drawing.Point(537, 209);
            this.txtFoodName.Name = "txtFoodName";
            this.txtFoodName.Size = new System.Drawing.Size(178, 26);
            this.txtFoodName.TabIndex = 18;
            // 
            // txtFoodID
            // 
            this.txtFoodID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFoodID.Location = new System.Drawing.Point(537, 171);
            this.txtFoodID.Name = "txtFoodID";
            this.txtFoodID.Size = new System.Drawing.Size(178, 26);
            this.txtFoodID.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Cyan;
            this.label7.Location = new System.Drawing.Point(339, 246);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 25);
            this.label7.TabIndex = 16;
            this.label7.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Cyan;
            this.label5.Location = new System.Drawing.Point(339, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 25);
            this.label5.TabIndex = 15;
            this.label5.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Cyan;
            this.label4.Location = new System.Drawing.Point(339, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "Food ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepPink;
            this.label3.Location = new System.Drawing.Point(199, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 39);
            this.label3.TabIndex = 13;
            this.label3.Text = "Add Food";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuText;
            this.panel1.Controls.Add(this.btnofferdetails);
            this.panel1.Controls.Add(this.btnmanageoffers);
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnfooddetails);
            this.panel1.Controls.Add(this.btnmanagefood);
            this.panel1.Controls.Add(this.btnaddfood);
            this.panel1.Controls.Add(this.btnuserdetails);
            this.panel1.Controls.Add(this.btnmanageuser);
            this.panel1.Controls.Add(this.btnadduser);
            this.panel1.Location = new System.Drawing.Point(0, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 582);
            this.panel1.TabIndex = 22;
            // 
            // btnofferdetails
            // 
            this.btnofferdetails.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnofferdetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnofferdetails.FlatAppearance.BorderSize = 0;
            this.btnofferdetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnofferdetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnofferdetails.ForeColor = System.Drawing.Color.Cyan;
            this.btnofferdetails.Location = new System.Drawing.Point(-2, 449);
            this.btnofferdetails.Name = "btnofferdetails";
            this.btnofferdetails.Padding = new System.Windows.Forms.Padding(3);
            this.btnofferdetails.Size = new System.Drawing.Size(182, 60);
            this.btnofferdetails.TabIndex = 9;
            this.btnofferdetails.Text = "Offer Details";
            this.btnofferdetails.UseVisualStyleBackColor = false;
            this.btnofferdetails.Click += new System.EventHandler(this.btnofferdetails_Click);
            // 
            // btnmanageoffers
            // 
            this.btnmanageoffers.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnmanageoffers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmanageoffers.FlatAppearance.BorderSize = 0;
            this.btnmanageoffers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmanageoffers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanageoffers.ForeColor = System.Drawing.Color.Cyan;
            this.btnmanageoffers.Location = new System.Drawing.Point(0, 402);
            this.btnmanageoffers.Name = "btnmanageoffers";
            this.btnmanageoffers.Padding = new System.Windows.Forms.Padding(3);
            this.btnmanageoffers.Size = new System.Drawing.Size(182, 60);
            this.btnmanageoffers.TabIndex = 8;
            this.btnmanageoffers.Text = "Manage Offers";
            this.btnmanageoffers.UseVisualStyleBackColor = false;
            this.btnmanageoffers.Click += new System.EventHandler(this.btnmanageoffers_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlogout.FlatAppearance.BorderSize = 0;
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.Cyan;
            this.btnlogout.Location = new System.Drawing.Point(-1, 497);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Padding = new System.Windows.Forms.Padding(3);
            this.btnlogout.Size = new System.Drawing.Size(182, 60);
            this.btnlogout.TabIndex = 7;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.UseVisualStyleBackColor = false;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.ForeColor = System.Drawing.Color.Coral;
            this.panel2.Location = new System.Drawing.Point(-2, -7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 108);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LavenderBlush;
            this.label2.Location = new System.Drawing.Point(28, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Restuarant";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LavenderBlush;
            this.label1.Location = new System.Drawing.Point(28, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "hafty_";
            // 
            // btnfooddetails
            // 
            this.btnfooddetails.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnfooddetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfooddetails.FlatAppearance.BorderSize = 0;
            this.btnfooddetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfooddetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfooddetails.ForeColor = System.Drawing.Color.Cyan;
            this.btnfooddetails.Location = new System.Drawing.Point(-1, 355);
            this.btnfooddetails.Name = "btnfooddetails";
            this.btnfooddetails.Padding = new System.Windows.Forms.Padding(3);
            this.btnfooddetails.Size = new System.Drawing.Size(182, 60);
            this.btnfooddetails.TabIndex = 6;
            this.btnfooddetails.Text = "Food Details";
            this.btnfooddetails.UseVisualStyleBackColor = false;
            this.btnfooddetails.Click += new System.EventHandler(this.btnfooddetails_Click);
            // 
            // btnmanagefood
            // 
            this.btnmanagefood.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnmanagefood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmanagefood.FlatAppearance.BorderSize = 0;
            this.btnmanagefood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmanagefood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanagefood.ForeColor = System.Drawing.Color.Cyan;
            this.btnmanagefood.Location = new System.Drawing.Point(-1, 302);
            this.btnmanagefood.Name = "btnmanagefood";
            this.btnmanagefood.Padding = new System.Windows.Forms.Padding(3);
            this.btnmanagefood.Size = new System.Drawing.Size(182, 60);
            this.btnmanagefood.TabIndex = 5;
            this.btnmanagefood.Text = "Manage Food";
            this.btnmanagefood.UseVisualStyleBackColor = false;
            this.btnmanagefood.Click += new System.EventHandler(this.btnmanagefood_Click_1);
            // 
            // btnaddfood
            // 
            this.btnaddfood.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnaddfood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnaddfood.FlatAppearance.BorderSize = 0;
            this.btnaddfood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnaddfood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddfood.ForeColor = System.Drawing.Color.Cyan;
            this.btnaddfood.Location = new System.Drawing.Point(-2, 253);
            this.btnaddfood.Name = "btnaddfood";
            this.btnaddfood.Padding = new System.Windows.Forms.Padding(3);
            this.btnaddfood.Size = new System.Drawing.Size(183, 60);
            this.btnaddfood.TabIndex = 4;
            this.btnaddfood.Text = "Add Food";
            this.btnaddfood.UseVisualStyleBackColor = false;
            this.btnaddfood.Click += new System.EventHandler(this.btnaddfood_Click);
            // 
            // btnuserdetails
            // 
            this.btnuserdetails.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnuserdetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnuserdetails.FlatAppearance.BorderSize = 0;
            this.btnuserdetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserdetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserdetails.ForeColor = System.Drawing.Color.Cyan;
            this.btnuserdetails.Location = new System.Drawing.Point(-2, 207);
            this.btnuserdetails.Name = "btnuserdetails";
            this.btnuserdetails.Padding = new System.Windows.Forms.Padding(3);
            this.btnuserdetails.Size = new System.Drawing.Size(182, 60);
            this.btnuserdetails.TabIndex = 3;
            this.btnuserdetails.Text = "User Details";
            this.btnuserdetails.UseVisualStyleBackColor = false;
            this.btnuserdetails.Click += new System.EventHandler(this.btnuserdetails_Click);
            // 
            // btnmanageuser
            // 
            this.btnmanageuser.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnmanageuser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmanageuser.FlatAppearance.BorderSize = 0;
            this.btnmanageuser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmanageuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanageuser.ForeColor = System.Drawing.Color.Cyan;
            this.btnmanageuser.Location = new System.Drawing.Point(-2, 153);
            this.btnmanageuser.Name = "btnmanageuser";
            this.btnmanageuser.Padding = new System.Windows.Forms.Padding(3);
            this.btnmanageuser.Size = new System.Drawing.Size(182, 60);
            this.btnmanageuser.TabIndex = 2;
            this.btnmanageuser.Text = "Manage Users";
            this.btnmanageuser.UseVisualStyleBackColor = false;
            this.btnmanageuser.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnadduser
            // 
            this.btnadduser.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnadduser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnadduser.FlatAppearance.BorderSize = 0;
            this.btnadduser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadduser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadduser.ForeColor = System.Drawing.Color.Cyan;
            this.btnadduser.Location = new System.Drawing.Point(-1, 101);
            this.btnadduser.Name = "btnadduser";
            this.btnadduser.Padding = new System.Windows.Forms.Padding(3);
            this.btnadduser.Size = new System.Drawing.Size(182, 62);
            this.btnadduser.TabIndex = 1;
            this.btnadduser.Text = "Add User";
            this.btnadduser.UseVisualStyleBackColor = false;
            this.btnadduser.Click += new System.EventHandler(this.button1_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton1.Location = new System.Drawing.Point(780, 32);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(95, 34);
            this.metroButton1.TabIndex = 23;
            this.metroButton1.Text = "Dashboard";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Add_food
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 586);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtFoodName);
            this.Controls.Add(this.txtFoodID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.MaximizeBox = false;
            this.Name = "Add_food";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Magenta;
            this.Text = "Add_food";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Add_food_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtFoodName;
        private System.Windows.Forms.TextBox txtFoodID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnofferdetails;
        private System.Windows.Forms.Button btnmanageoffers;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnfooddetails;
        private System.Windows.Forms.Button btnmanagefood;
        private System.Windows.Forms.Button btnaddfood;
        private System.Windows.Forms.Button btnuserdetails;
        private System.Windows.Forms.Button btnmanageuser;
        private System.Windows.Forms.Button btnadduser;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}