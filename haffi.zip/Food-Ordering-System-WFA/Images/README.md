This Folder contains all the diagrams and screen shots of the developed system.
