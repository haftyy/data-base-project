# Food-Ordering-System-WFA
## Introduction
This Software project is merely describing a point of sales system of a restaurant. A restaurant point of sales system will help usher a new level of efficiency in the business process. And, this system offers many modules for billing, managing foods, offers, labors and centralized access management.<br>

Maintaining a restaurant sale is a very important thing when it comes to restaurants. To achieve business goals, restaurant management should have efficient control over the business procedure. Effective management is a piece of cake when you have a Point of Sales system in your premises as you can accurately keep a record of everything that happens in your restaurant. Using the Point of Sales system, you can generate sales reports and inventory reports to analyze your business and understand the trends and needs of your customers. Customer satisfaction is one of most important things on a business. With a restaurant point of sales system, you can effectively increase customer satisfaction to the maximum level. <br>

Beyond those things there are so much more that a Restaurant Point of Sales system can do. This project facilitates basic operations of a restaurant system. And many more to be implemented. <br>

## Case Study

Customers select and tell the cashier the food items and the cashier select the food items according to the customer’s requirement. The cashier can add and remove the food items any time before ordering. Offers are also provided to the customer and offers are updated, and new offers are added when there are special occasions. The administrator of the system adds these offers. The added items by the customer will be displayed on the right side of the screen where the cashier can add or remove and see what they said and see the price of all the items and total price. Once the order is done, the system issues a bill with order details and the order number. 

The customer can make the payment and receive the food when they are ready. In this system, all the executive operations such as adding or removing cashiers to the system, adding and/or removing food items to the menu is done by the administration while the cashier is only capable of generating bills. Administration is also given the opportunity of updating and checking details of current cashiers, food items and offers so that the security of the system is thoroughly enhanced, and no other external party can access the system’s data. 

The aim of this system is to make the client and the cashier comfortable and to make things simple for the cashier when they select food items. And, especially to reduce the time when the customer takes something to select and order. This system is implemented to make the customer and the cashier feel it is simple and easy to order the food items.

## Requirements of The System

•	The system should be able to enroll new users (admins and cashiers).<br>
•	Admins must be provided with a more advanced and functional dashboard other than normal users as they are assessed with much more duties and responsibilities.<br>
•	Admins should be able to add/remove/update/check cashiers and their details.<br>
•	Admins should be able to add/remove/update/check offers and various food items.<br>
•	Cashiers should be capable of generating the bills.<br>

# Diagrams:

## ER Diagram
![ER Diagram](https://github.com/lihini223/Food-Ordering-System-WFA/blob/master/Images/ER%20diagram.png)

## Use Case Diagram
![use case diagram](https://github.com/lihini223/Food-Ordering-System-WFA/blob/master/Images/Use%20Case%20diagram.png)

## Class Diagram
![class diagram](https://github.com/lihini223/Food-Ordering-System-WFA/blob/master/Images/class%20diagram.jpg)

# Samples of the developed system

## Welcome Page
The welcome page is the first form of the software. It provides users the accessibility to login to the system. The users can log into their respective admin or normal user accounts by clicking on the appropriate radio button. This form redirects to the admin’s dashboard.<br>
